#include "BusRS485.h"

// размер буфера дополнительных данных
// размер 24 выбран для размещения в стандартном буфере двух полных пакетов 
// что бы уменьшить потери при задержках в обработки поступившего пакета
#define MIN_BUFFER 24 

// маркер начала кадра (введен для стабильности распознования кадров), всегда $ED, B11101101, 237  
#define MARK 237

//-------------------PUBLIC FUNCTIONS------------------------------------------

// конструктор для мастера
BusRS485::BusRS485(uint8_t PortNum, uint8_t CPinRx, uint8_t CPinTx) {
  FStatus = 0;
  this->Echo = 0;
  if (MAX_BUFFER < MIN_BUFFER) {
    FStatus = FStatus  | B00000010;
  }
 
  switch( PortNum ) {
  #if defined(UBRR1H)
  case 1:
    port = &Serial1;
    break;
  #endif

  #if defined(UBRR2H)
  case 2:
    port = &Serial2;
    break;
  #endif

  #if defined(UBRR3H)
  case 3:
    port = &Serial3;
    break;
  #endif
  case 0:
  default:
    port = &Serial;
    break;
  }
  
  MaskRW = 0;
//  MaskRWI = 0;

  if (CPinRx > 1 && CPinRx < 7) { 
    pinMode(CPinRx, OUTPUT); 
    bitSet(MaskRW, CPinRx);
  }
  if (CPinTx > 1 && CPinTx < 7) { 
    pinMode(CPinTx, OUTPUT); 
    bitSet(MaskRW, CPinTx);
  }
  if (CPinRx > 1 && CPinRx < 7 && CPinTx > 1 && CPinTx < 7 && CPinTx != CPinRx) {;}
  
}

void BusRS485::InitEnd(){         
  // закрытие соединения
  off();
  port->flush();
  port->end();
  FInPack = 0;
}


void BusRS485::InitMaster(long Speed){     // скорость порта
  // это мастер !!!!

  PauseWrite =   (10000.0 / 9600 * 1000)   // это время на отправку 10 бит эха в порт USB со скоростью 9600, 
                                           // нужна в случае включенного эха на устройствах для которых предназначена передача 
                                           // это время через которое устройства шины перейдут из режима Write в режим Read
               + (10000.0 / Speed * 1000); // это время на отправку 10 бит в порт 485 с установленой скоростью, 
                                           // такая пауза обеспечивает синхронизацию на физическом уровне (удаление ложного бита начала посылки)
  
  Id_Unit = 0;    
  port->begin(Speed);
  port->flush();
  onRead();
  delay(100);
  FInPack = 0;
}

void BusRS485::InitSlave(long Speed,           // скорость порта 
                         uint8_t Id,           // Id слейва 
                         void (*_OnSlave)()){  // пользовательская функция для обработки получения неожидаемого пакета от мастера
                         
  PauseWrite =   (10000.0 / 9600 * 1000)   // это время на отправку 10 бит эха в порт USB со скоростью 9600, 
                                           // нужна в случае включенного эха на устройствах для которых предназначена передача 
                                           // это время через которое устройства шины перейдут из режима Write в режим Read
               + (10000.0 / Speed * 1000); // это время на отправку 10 бит в порт 485 с установленой скоростью, 
                                           // такая пауза обеспечивает синхронизацию на физическом уровне (удаление ложного бита начала посылки)
  

  if (Id <= 0 || Id > 240) { // ошибочный ID 
    FStatus = FStatus | B00000001;
    this->Id_Unit = 241;    
  }
  else {
    this->Id_Unit = Id;    
  }
  
  OnSlave = _OnSlave;
  port->begin(Speed);
  port->flush();
  onRead();
  delay(100);
  FInPack = 0;
}

//------------------------------------------------------------------
// простая команда из одного пакета без ожидания ответа
void BusRS485::Command(uint8_t Id,       // Id получателя пакета
                       uint8_t Func,     // номер функции
                       uint8_t SizeDate, // размер дополнительных данных, не более 24 байт
                       uint8_t *Data){   // указатель на буфер дополнительных данных 
  
  Reply.OnReply = false;
  if (this->send(
         Id,            // ID получателя
         Func,          // номер функции
         1,             // номер кадра в команде
         1,             // всего кадров в команде
         false,         // флаг ошибки
         false,         // флаг ожидания
         false,         // флаг повтора
         false,         // флаг подтверждения
         SizeDate,      // размер дополнительных данных
         &(Data[0]))    // указатель на буфер дополнительных данных 
         == false) {    // попытка отправить слишком много данных, это критическая ошибка и отправка была заблокирована
     FStatus = FStatus | B10000000; // установим восьмой бит ошибки
  }
  
  if (this->Id_Unit > 0) {
       // попытка отправить простую команду со слейва - это ошибка, но не критическая, 
       // команда все равно будет отправлена, но она будет игнорироватся получателями 
       // отправка таких команды оставлена для резерва на будущее расширения возможностей
       FStatus = FStatus | B01000000; // установим седьмой бит ошибки
  }
}

//------------------------------------------------------------------
// начало команды из нескольких пакетов
void BusRS485::Command(uint8_t Id,              // Id получателя пакета
                       uint8_t Func,            // номер функции
                       uint8_t CountPack,       // всего кадров в команде
                       uint8_t SizeDate,        // размер дополнительных данных
                       uint8_t *Data,           // указатель на буфер дополнительных данных 
                       int TimeOut,             // время которое будем ожидать ответный пакет
                       unsigned long StartTime, // время начала ожидания ответного пакета               
                       void (*_userFunc)()){    // процедура вызываемая при получении ответа
  
  Reply.OnReply = false;  
  if (this->Id_Unit > 0) {
     // попытка отправить сложную команду со слейва - это критическая ошибка и отправка была заблокирована 
     FStatus = FStatus | B10000000; // установим восьмой бит ошибки
  }
  else if (this->send(
         Id,            // ID получателя
         Func,          // номер функции
         1,             // номер кадра в команде
         CountPack,     // всего кадров в команде
         false,         // флаг ошибки
         false,         // флаг ожидания
         false,         // флаг повтора
         false,         // флаг подтверждения
         SizeDate,      // размер дополнительных данных
         &(Data[0]))    // указатель на буфер дополнительных данных 
         == false) {    
     // попытка отправить слишком много данных - это критическая ошибка и отправка была заблокирована
     FStatus = FStatus | B10000000; // установим восьмой бит ошибки
  }
  else if (CountPack > 1) {  
    // отправка прошла, устанавливаем параметры ожидания ответа
    Reply.OnReply = true;
    Reply.TimeOut = TimeOut;
    Reply.StartTime = StartTime;
    Reply.Id_Destination = this->Id_Unit;
    Reply.Id_Source = Id;
    Reply.Control_1 = (CountPack << 4) | Func;
    Reply.Control_2 = 2;
    Reply.Reply_OnStep = _userFunc;;
  }
}

//------------------------------------------------------------------
// не первый пакет из сложной команды (вызывается из обработчиков ответа)
void BusRS485::Command(uint8_t Id,              // Id получателя пакета
                       uint8_t Func,            // номер функции
                       uint8_t Pack,            // номер кадра в команде
                       uint8_t CountPack,       // всего кадров в команде
                       boolean F1,              // флаг ошибки
                       boolean F2,              // флаг ожидания
                       boolean F3,              // флаг повтора
                       boolean F4,              // флаг подтверждения
                       uint8_t SizeDate,        // размер дополнительных данных
                       uint8_t *Data,           // указатель на буфер дополнительных данных 
                       int TimeOut,             // время которое будем ожидать ответный пакет
                       unsigned long StartTime, // время начала ожидания ответного пакета               
                       void (*_userFunc)()){    // процедура вызываемая при получении ответа
  
  Reply.OnReply = false;  
  if (Pack == 1) {
     // попытка отправить первый кадр команды - это критическая ошибка и отправка была заблокирована 
     FStatus = FStatus | B10000000; // установим восьмой бит ошибки
  }
  else if (this->send(
         Id,            // ID получателя
         Func,          // номер функции
         Pack,          // номер кадра в команде
         CountPack,     // всего кадров в команде
         F1,            // флаг ошибки
         F2,            // флаг ожидания
         F3,            // флаг повтора
         F4,            // флаг подтверждения
         SizeDate,      // размер дополнительных данных
         &(Data[0]))    // указатель на буфер дополнительных данных 
         == false) {    
     // попытка отправить слишком много данных - это критическая ошибка и отправка была заблокирована
     FStatus = FStatus | B10000000; // установим восьмой бит ошибки
  }
  else if (CountPack > Pack) {  
    // отправка прошла, устанавливаем параметры ожидания ответа
    Reply.OnReply = true;
    Reply.TimeOut = TimeOut;
    Reply.StartTime = StartTime;
    Reply.Id_Destination = this->Id_Unit;
    Reply.Id_Source = Id;
    Reply.Control_1 = (CountPack << 4) | Func;
    Reply.Control_2 = (Pack+1);
    Reply.Reply_OnStep = _userFunc;;
  }
}


//------------------------------------------------------------------
uint8_t BusRS485::Id (void)         { return Id_Unit; }
uint8_t BusRS485::Status (void)     { return FStatus; }
void BusRS485::SetEcho(uint8_t a)   { this->Echo = a; }

uint8_t BusRS485::Id_Destination () { return InPack.Id_Destination; }
uint8_t BusRS485::Id_Source ()      { return InPack.Id_Source; }
uint8_t BusRS485::SizeDate ()       { return InPack.SizeDate; }
uint8_t * BusRS485::Date ()         { return &(InPack.Data[0]); }

uint8_t BusRS485::NumFunc ()   { return (InPack.Control_1 & B00001111); }
uint8_t BusRS485::CountCadr () { return (InPack.Control_1 >> 4); }
uint8_t BusRS485::NumCadr ()   { return (InPack.Control_2 & B00001111); }
boolean BusRS485::FError ()    { return ((InPack.Control_2 >> 4) & B00000001); }
boolean BusRS485::FWait ()     { return ((InPack.Control_2 >> 5) & B00000001); }
boolean BusRS485::FRetry ()    { return ((InPack.Control_2 >> 6) & B00000001); }
boolean BusRS485::FValidate () { return (InPack.Control_2 >> 7); }

boolean BusRS485::OnReply (void)          { return Reply.OnReply; }
boolean BusRS485::OnReply (boolean value) { Reply.OnReply = value; return Reply.OnReply; }
uint8_t BusRS485::ReplyId (void)          { return Reply.Id_Source; }    
uint8_t BusRS485::ReplyNumFunc ()         { return (Reply.Control_1 & B00001111); }

int BusRS485::TimeOut (void)              { return Reply.TimeOut; }
unsigned long BusRS485::StartTime (void)  { return Reply.StartTime; }


void BusRS485::onRead() {
  port->flush();                        // ждем пока завершится отправка
  PORTD = PORTD & (B11111111 ^ MaskRW); // оба пина выключены
//  if ((CPinRx > 1)&&(CPinTx > 1)) { 
//    //    FStatus = FStatus ^ B11110111;
//    port->flush();
//    digitalWrite(CPinTx, LOW); // отправка выключена
//    digitalWrite(CPinRx, LOW); // получение включено (RE инверсный) 
//  }
} 

void BusRS485::onWrite() {
  port->flush();                        // ждем пока завершится предыдущая отправка, возможно было эхо
  PORTD = PORTD | MaskRW; // оба пина включены
//  if ((CPinRx > 1)&&(CPinTx > 1)) { 
//    //    FStatus = FStatus ^ B11110111;
//    port->flush();
//    digitalWrite(CPinRx, HIGH); // получение выключено (RE инверсный)
//    digitalWrite(CPinTx, HIGH); // отправка включена
//  }
} 

void BusRS485::off() {
//  if ((CPinRx > 1)&&(CPinTx > 1)) { 
//    //    FStatus = FStatus ^ B11110111;
//    digitalWrite(CPinRx, HIGH); // получение выключено (RE инверсный)
//    digitalWrite(CPinTx, LOW);  // отправка выключена
//    port->flush();
//  }
} 

uint8_t BusRS485::Read(){
  uint8_t a; 
  a = port->read();
  if (this->Echo == 1) { port->write(a); }
  return a; 
}

void BusRS485::poll() {
  uint8_t mCRC = 0;
  uint8_t i1 = 0;
  int ii;

  while (true) {
    // FInPack=0
    //    0-ждем заголовок 
    //    1-ждем дополнительные данные 
    //    2-пакет загружен валиден 
    //    3-пакет загружен, но не валиден
    
    if (FInPack > 3) {FInPack = 0;}  // не понятный флаг, значит будем ждать заголовок
    else if (FInPack == 2) {break;}  // пакет загружен и не обработан
    else if (FInPack == 3) {break;}  // пакет загружен и не валиден
    
    ii = port->available();
    
    if (FInPack == 0 && ii < 8) {
      break; // ждем заголовка, но данных мало
    } 

    if (ii >= 8 && port->peek(0) == MARK) { // возможно это заголовок пакета, посчитаем контрольный символ

      mCRC =  CRC(MARK, mCRC);
      mCRC =  CRC(port->peek(1), mCRC);
      mCRC =  CRC(port->peek(2), mCRC);
      mCRC =  CRC(port->peek(3), mCRC);
      mCRC =  CRC(port->peek(4), mCRC);
      mCRC =  CRC(port->peek(5), mCRC);
      mCRC =  CRC(port->peek(6), mCRC);

      if (mCRC == port->peek(7)) {
        // да это заголовок пакета, 
        // если мы ждали доп данные от предыдущего пакета - про них забудем, грузим новый пакет
        
        // загрузим заголовок пакета
        InPack.Mark           = Read();
        InPack.Id_Destination = Read();
        InPack.Id_Source      = Read();
        InPack.Control_1      = Read();
        InPack.Control_2      = Read(); 
        InPack.SizeDate       = Read(); 
        InPack.CRC_Data       = Read(); 
        InPack.CRC_Head       = Read(); 
        
        if (InPack.SizeDate == 0) {
          // пакет не содержит дополнительных данных, только номер и команду
          FInPack = 2;
          break;
        }
        else { 
          // заголовок загружен, нужно пытатся загрузить данные
          FInPack = 1; 
          //ii = port->available();
          continue;
        }
      }
    }
    
    if (FInPack == 1) { // ждем доп данные
      if (ii >= InPack.SizeDate) {
        // Загрузим доп данные вне зависимости от CRC
        for (int i1=0; i1 < InPack.SizeDate; i1++){ InPack.Data[i1] = Read(); } 
        //теперь проверим валидность
        mCRC = 0;
        for (int i1=0; i1 < InPack.SizeDate; i1++){ mCRC = CRC(InPack.Data[i1], mCRC); } 
        if (mCRC == InPack.CRC_Data) { FInPack = 2; }   // это правильные дополнительные данные
        else                         { FInPack = 3; }   // контроль доп данных не сошелся весь пакет выкенем
      } 
    }
    break;
  } // ---- while ------
  
  if (FInPack == 2) { 
    if (Id_Unit == InPack.Id_Source) {
      // мы видим входящий пакет от устройства с нашим ID, это ошибка, в сети 2 устройства с одним ID
      FStatus = FStatus | B00000101;
      Id_Unit = 241;    
      Reply.OnReply = false;
    }
    else if (Id_Unit == 0) {
      // это мастер, на нем обрабатываем только пакеты которые мы ожидаем
      // неожиданно пришедшие пакеты пришедшие на мастер пропускаем

      if (   Reply.OnReply 
          && Reply.Id_Destination == InPack.Id_Destination
          && Reply.Id_Source == InPack.Id_Source
          && Reply.Control_1 == InPack.Control_1
          && Reply.Control_2 == (InPack.Control_2 & B00001111)
          ) {
            
       // запускаем подключеную обработку ответа   
       Reply.OnReply = false;
       Reply.Reply_OnStep();    
      }
    }  
    else {
      // это слейв, на нем обрабатываем 
      // 1. ожидаемые ответы
      // 2. широковещательные пакеты
      // 3. новые пакеты от мастера
      if (   Reply.OnReply 
          && Reply.Id_Destination == InPack.Id_Destination
          && Reply.Id_Source == InPack.Id_Source
          && Reply.Control_1 == InPack.Control_1
          && Reply.Control_2 == (InPack.Control_2 & B00001111)
          ) {
        // это ожидаемый пакет    
        // запускаем подключеную обработку           
       Reply.OnReply = false;
       Reply.Reply_OnStep();    
      } 
      // кроме ожидаемых ответов на слейве отрабатываем вариант прихода новой команы
      else if (InPack.Id_Destination == 255) {
        // это широковещательный пакет   
        Reply.OnReply = false;
        OnSlave();
      }
      else if (InPack.Id_Destination == Id_Unit
            && InPack.Id_Source == 0) {
        // это новый пакет от мастера      
        Reply.OnReply = false;
        OnSlave();
      }  
    }
    FInPack = 0;
  }  
  
  if (FInPack > 1) { FInPack = 0; } 
}


// ------------------PRIVATE FUNCTIONS------------------------------

boolean BusRS485::send(uint8_t Id,         // ID получателя
                       uint8_t Func,       // номер функции
                       uint8_t Pack,       // номер кадра в команде
                       uint8_t CountPack,  // всего кадров в команде
                       boolean F1,         // флаг ошибки
                       boolean F2,         // флаг ожидания
                       boolean F3,         // флаг повтора
                       boolean F4,         // флаг подтверждения
                       uint8_t SizeDate,   // размер дополнительных данных
                       uint8_t *Data) {    // указатель на буфер дополнительных данных 

  if (MAX_BUFFER >= SizeDate) {   // посылаем только если доп данные влезут в буфер
  
    uint8_t CRC_Data = 0;         // CRC дополнительных данных пакета
    uint8_t CRC_Head = 0;         // CRC заголовка, служит для определения корректности заголовка и выделения кадра из потока данных
    uint8_t a = (CountPack << 4) | Func;       
    uint8_t b = (F1 << 7) | (F2 << 6) | (F3 << 5) | (F4 << 4) | Pack;       
    
    for (int i=0; i < SizeDate; i++){ 
      CRC_Data = CRC(Data[i], CRC_Data);
    } 
  
    CRC_Head = CRC(CRC_Head, MARK);
    CRC_Head = CRC(CRC_Head, Id);
    CRC_Head = CRC(CRC_Head, Id_Unit);
    CRC_Head = CRC(CRC_Head, a);
    CRC_Head = CRC(CRC_Head, b);
    CRC_Head = CRC(CRC_Head, SizeDate);
    CRC_Head = CRC(CRC_Head, CRC_Data);

    onWrite();
    // перед отправкой выдержем паузу для того, что-бы остальные успелись переключится в режим приема
    delayMicroseconds(PauseWrite); 
    
    port->write(MARK);
    port->write(Id);
    port->write(Id_Unit);
    port->write(a);
    port->write(b);
    port->write(SizeDate);
    port->write(CRC_Data);
    port->write(CRC_Head);
    
    for (int i=0; i < SizeDate; i++){ 
      port->write(Data[i]);
    } 
    onRead(); 
    return true;
  } 
  else {
    return false;
  }
}

// ---------------------------------------------
// функция делает XOR и после циклический сдвиг
uint8_t BusRS485::CRC(uint8_t a, uint8_t b) {
  uint8_t c;
  c = a ^ b;
  return (c << 1) | (c >> 7);
}

